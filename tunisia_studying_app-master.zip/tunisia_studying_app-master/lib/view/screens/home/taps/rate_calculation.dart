import 'package:flutter/material.dart';

class RateCalculationScreen extends StatefulWidget {
  const RateCalculationScreen({Key? key}) : super(key: key);

  @override
  State<RateCalculationScreen> createState() => _RateCalculationScreenState();
}

class _RateCalculationScreenState extends State<RateCalculationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
