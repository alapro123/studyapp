import 'package:flutter/material.dart';
class VerticalScreenLayout extends StatelessWidget {
  const VerticalScreenLayout({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('vertical'),
      ),
    );
  }
}