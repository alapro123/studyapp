enum DeviceScreenType{
  mobile,
  tablet,
}