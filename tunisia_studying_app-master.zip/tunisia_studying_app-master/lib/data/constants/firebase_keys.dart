class FirebaseKeys {
  static const senderEmail = 'senderEmail';
  static const messageText = 'messageText';
  static const time = 'time';
}
